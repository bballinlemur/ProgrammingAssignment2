cacheSolve <- function(x, ...) {
       m <- x$getsolve()
        if(!is.null(m)) {
                message("getting cached data")
                return(m)
        }
        data <- x$get()
	  message("solving inverse")
        m <- solve(data, ...)
        x$matsolve(m)
        m
}