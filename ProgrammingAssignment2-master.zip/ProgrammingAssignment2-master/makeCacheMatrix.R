makeCacheMatrix <- function(x = numeric()) {
        m <- NULL
        set <- function(y) {
                x <<- y
                m <<- NULL
        }
        get <- function() x
        matsolve <- function(solve) m <<- solve
        getsolve <- function() m
        list(set = set, get = get,
             matsolve = matsolve,
             getsolve = getsolve)
}